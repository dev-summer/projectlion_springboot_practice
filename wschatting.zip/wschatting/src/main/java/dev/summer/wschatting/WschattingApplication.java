package dev.summer.wschatting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WschattingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WschattingApplication.class, args);
	}

}
