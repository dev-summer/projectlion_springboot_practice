package dev.summer.wschatting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WschattingApplicationTests {

	@Test
	void contextLoads() {
	}

}
