package dev.summer.subscriber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubscriberApplicationTests {

	@Test
	void contextLoads() {
	}

}
