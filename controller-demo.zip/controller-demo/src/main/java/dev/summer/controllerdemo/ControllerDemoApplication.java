package dev.summer.controllerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControllerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControllerDemoApplication.class, args);
	}

}
