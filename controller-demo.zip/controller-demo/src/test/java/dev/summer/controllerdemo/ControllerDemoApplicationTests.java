package dev.summer.controllerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControllerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
